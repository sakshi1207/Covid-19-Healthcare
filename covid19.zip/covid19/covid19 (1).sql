-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2020 at 11:04 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid19`
--

-- --------------------------------------------------------

--
-- Table structure for table `foodrequests`
--

CREATE TABLE `foodrequests` (
  `sr_no` int(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `person` varchar(300) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foodrequests`
--

INSERT INTO `foodrequests` (`sr_no`, `email`, `name`, `person`, `mobile`, `address`, `city`) VALUES
(6, 'parasanand12@gmail.c', 'Paras', '5', '9517202235', 'hno 84,st no 6, tilak nagar, haryana', 'Haryana'),
(7, 'anandakshay07@gmail.', 'Akshay', '30', '9814159615', 'hno 486, st no 3, nehru gate, Batala', 'Batala'),
(15, 'sakshianandk@gmail.c', 'sakshi', '7', '9517231120', 'hno76, stno 5, tehsilpura, asr', 'Amritsar'),
(16, 'sakshianandk@gmail.c', 'sakshi', '30', '9517231120', 'hno 62,st no 6,tehsilpuraa ', 'amritsar'),
(17, 'sakshianandk@gmail.c', 'sakshi', '30', '9517231120', 'hno 62,st no 6,tehsilpuraa ', 'amritsar'),
(18, 'sakshianandk@gmail.c', 'sakshi', '30', '9517231120', 'hno 62,st no 6,tehsilpuraa ', 'amritsar');

-- --------------------------------------------------------

--
-- Table structure for table `ngonames`
--

CREATE TABLE `ngonames` (
  `email` varchar(40) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngonames`
--

INSERT INTO `ngonames` (`email`, `name`, `password`, `city`, `address`) VALUES
('sukh@gmail.com', 'Sukh NGO', 'sukh12', 'amritsar', 'Dashmesh nagar'),
('vidhan@gmail.com', 'Vidhan NGO', 'vidhan123', 'delhi', 'Gt Road');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `name`, `password`, `gender`, `mobile`) VALUES
('alka123@gmail.com', 'Alka', 'alka12', 'female', '9814159615'),
('anandakshay07@gmail.com', 'Akshay', 'akshay12', 'male', '9914699551'),
('parasanand12@gmail.com', 'Paras', 'paras12', 'male', '9517202235'),
('sakshianandk@gmail.com', 'sakshi', 'saku123', 'female', '9517231120');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foodrequests`
--
ALTER TABLE `foodrequests`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foodrequests`
--
ALTER TABLE `foodrequests`
  MODIFY `sr_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
