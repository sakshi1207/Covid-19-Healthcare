
from django import *
from django.http import *
from django.shortcuts import *
from django.views.decorators.csrf import *
from pymysql import *
import http.client
con = connect("localhost", "root", "", "covid19")


def covid_helpline(request):
    return render(request, "covid_helpline.html")


def usersignup(request):
    return render(request, "usersignup.html")

def userlogout(request):
    del request.session["useremail"]
    return HttpResponseRedirect"covid_helpline")

def signuppage(request):
    global con
    email = request.GET["email"]
    username = request.GET["username"]
    password = request.GET["password"]
    gender = request.GET["gender"]
    mobile = request.GET["mobile"]

    s = "insert into users values ('" + email + "','" + username + "','" + password + "','" + gender + "','" + mobile + "')"
    cr = con.cursor()
    cr.execute(s)
    con.commit()
    return render(request, "covid_helpline.html")


def userlogin(request):
    return render(request, "userlogin.html")


@csrf_exempt
def userloginpage(request):
    global con
    email = request.POST['email']
    password = request.POST['password']

    cr = con.cursor()
    query = "select * from users where email='" + email + "' and password='" + password + "';"
    print(query)
    cr.execute(query)
    result = cr.fetchone()
    if result == None:
        return render(request, "errorpage.html")
    else:
        request.session['useremail'] = email
        return render(request, "userdashboard.html", {"ar": request.session['useremail']})


def foodrequestform(request):
    email = request.session['useremail']
    return render(request, "foodrequestform.html", {"ar": email})


@csrf_exempt
def senddetails(request):
    email = request.session['useremail']
    name = request.POST['username']
    person = request.POST['person']
    mobile = request.POST['mobile']
    address = request.POST['address']
    city= request.POST["city"]
    s = "insert into foodrequests values (NULL,'" + email + "','" + name + "','" + person + "','" + mobile + "','" + address + " ','"+city+"')"
    cr = con.cursor()
    cr.execute(s)
    con.commit()
    return render(request, "userdashboard.html")


def govtloginpage(request):
    return render(request, "govtloginpage.html")


def logingovt(request):
    username = request.POST["email"]
    password = request.POST["password"]
    if username == "govt" and password == "govt":
        request.session["govtname"] = username
        return render(request, "govtmainpage.html", {"ar": request.session["govtname"]})
    else:
        return render(request, "loginfailed.html")


def govtmainpage(requests):
    return render(requests, "govtmainpage.html")


def foodrequests(request):
    return render(request, "foodrequests.html")

@csrf_exempt
def showusers(request):
    global con
    s1 = "SELECT * FROM foodrequests"
    crr = con.cursor()
    crr.execute(s1)
    result = crr.fetchall()
    print(result)
    d= []
    for row in result:
        dct = {}
        dct["sr"]=row[0]
        dct["email"]=row[1]
        dct["name"]=row[2]
        dct["person"]=row[3]
        dct["mobile"]=row[4]
        dct["address"]=row[5]
        dct["city"]=row[6]
        d.append(dct)
    return JsonResponse(d,safe=False)

# def fetchcity(request):
#     global con
#     city = request.GET['city']
#     print(city)
#     cr = con.cursor()
#     query1="select * from foodrequests where city='"+str(city)+"'"
#     print(query1)
#     cr.execute(query1)
#     rs=cr.fetchone()
#     d = []
#     for row in rs:
#         dct = {}
#         dct["sr"] = row[0]
#         dct["email"] = row[1]
#         dct["name"] = row[2]
#         dct["person"] = row[3]
#         dct["mobile"] = row[4]
#         dct["address"] = row[5]
#         dct["city"] = row[6]
#         d.append(dct)
#         return JsonResponse(d, safe=False)


@csrf_exempt
def acceptrequest(request):
    global con
    sr = request.POST["sr_no"]

    s2 = "DELETE FROM foodrequests WHERE sr_no = '"+sr+"'"
    cr = con.cursor()
    cr.execute(s2)
    con.commit()
    d={"message":"deleted successfully"}
    # msg = " Your request for food is accepted successfully"
    # msg = msg.replace(" ", "%20")
    # con = http.client.HTTPConnection("server1.vmm.education")
    # con.request('GET',
    #               "/VMMCloudMessaging/AWS_SMS_Sender?username=monika&password=L78E7CIB&message=" + msg + "&phone_numbers=" +
    #               request.POST["mobile"])
    # response = con.getresponse()
    # print(response.read())

    return JsonResponse(d,safe=False)

#-------------------------------
def ngologinpage(request):
    return render(request,"ngologinpage.html")

def checkngo(request):
    global con
    email = request.POST['email']
    password = request.POST['password']

    cr = con.cursor()
    query = "select * from ngonames where email='" + email + "' and password='" + password + "';"
    print(query)
    cr.execute(query)
    result = cr.fetchone()
    if result == None:
        return render(request, "errorpage.html")
    else:
        # request.session['useremail'] = email
        return render(request, "ngomainpage.html")

def ngomainpage(request):
    return render(request,"ngomainpage.html")
