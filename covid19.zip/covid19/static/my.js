function showusers() {
    var xx = new XMLHttpRequest();
    xx.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var output = JSON.parse(this.response);
            s = "";
            for (var i = 0; i < output.length; i++) {
                s += "<tr>";
                // s += "<td>" + output[i]["sr"] + "</td>";
                s += "<td>" + output[i]["email"] + "</td>";
                s += "<td>" + output[i]["name"] + "</td>";
                s += "<td>" + output[i]["person"] + "</td>";
                s += "<td>" + output[i]["mobile"] + "</td>";
                s += "<td>" + output[i]["address"] + "</td>";
                s += "<td>" + output[i]["city"] + "</td>";
                s += "<td><button id='button1' style='width: 70px;height: 50px' class='btn btn-success' onclick='acceptrequest(" + JSON.stringify(output[i]) + ")'>Accept</button></td>";
                s += "</tr>"
            }
            document.getElementById("users").innerHTML = s;
        }
    };
    xx.open("POST", "showusers", true);
    xx.send();
}

function acceptrequest(userinfo) {
    var sr = userinfo.sr;
    var name = userinfo.name;
    var person = userinfo.person;
    var mobile = userinfo.mobile;
    var address = userinfo.address;
    alert("Request accepted Successfully");
    alert("Now, it is your responsibility to send food at the following address:" + "\n\nName : " + name + "\nTotal persons : " + person + "\nMobile : " + mobile + "\nAddress : " + address);
    var fomdata = new FormData();
    fomdata.append("sr_no", sr);
    fomdata.append("mobile",mobile);
    var xx = new XMLHttpRequest();
    xx.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var output = JSON.parse(this.response);
            showusers();
        }
    };
    xx.open("POST", "acceptrequest", true);
    xx.send(fomdata);
}

