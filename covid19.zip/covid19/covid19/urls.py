"""covid19 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from controller import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",covid_helpline),
    path("covid_helpline",covid_helpline),
    path("usersignup",usersignup),
    path("signuppage",signuppage),
    path("userlogin",userlogin),
    path("userlogout",userlogout),
    path("userloginpage",userloginpage),
    path("foodrequestform",foodrequestform),
    path("senddetails",senddetails),
    path("govtloginpage",govtloginpage),
    path("logingovt",logingovt),
    path("govtmainpage",govtmainpage),
    path("foodrequests",foodrequests),
    path("showusers",showusers),
    # path("fetchcity",fetchcity),
    path("acceptrequest",acceptrequest),

    path("ngologinpage",ngologinpage),
    path("checkngo",checkngo),
    path("ngomainpage",ngomainpage),
]
